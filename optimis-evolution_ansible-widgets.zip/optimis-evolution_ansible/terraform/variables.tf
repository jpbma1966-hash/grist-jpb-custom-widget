variable "prefix_project" {
  type    = string
  default = "simple"
}

variable "ssh_public_keys" {
  default = [""]
}

variable "zone" {
  type = string
  default = "S1"
}

variable "env" {
  type = string
  default = "dev"
}

variable "region_tenant" {
  type = string
  default = "region1"
}

variable "volume_data_type" {
  default = "storwize"
  type = string
}

variable "volume_type" {
  default = "storwize"
  type = string
}

variable "tenant_name" {
  default = "test"
  type = string
}


##pio

variable "pio_image" {
  type    = string
  default = "debian12-mi-20260225"
}

variable "pio_public_access" {
  type    = bool
  default = true
}

variable "pio_volume_instance" {
  type    = number
  default = 10
}

variable "pio_list_instance" {
  type = list
  description = "List of instance's names"
  default = ["pio"]
}

variable "pio_volume_data" {
  type        = number
  description = "Size of volume instance, if 0 no volume attached"
  default     = 0
}

variable "pio_flavor" {
  type    = string
  default = "standard-pi-1.1"
}

variable "pio_environment" {
  type = map(any)
  default = {}
}

variable "pio_fixed_fip" {
  type = list
  default = ["172.20.83.107"]
}

##redis

variable "redis_image" {
  type    = string
  default = "debian12-mi-20260225"
}

variable "redis_public_access" {
  type    = bool
  default = false
}

variable "redis_volume_instance" {
  type    = number
  default = 10
}

variable "redis_list_instance" {
  type = list
  description = "List of instance's names"
  default = ["redis"]
}

variable "redis_volume_data" {
  type        = number
  description = "Size of volume instance, if 0 no volume attached"
  default     = 0
}

variable "redis_flavor" {
  type    = string
  default = "standard-pi-1.1"
}

variable "redis_environment" {
  type = map(any)
  default = {}
}

variable "redis_fixed_fip" {
  type = list
  default = []
}

##rpx

variable "rpx_image" {
  type    = string
  default = "debian12-mi-20260225"
}

variable "rpx_public_access" {
  type    = bool
  default = true
}

variable "rpx_volume_instance" {
  type    = number
  default = 10
}

variable "rpx_list_instance" {
  type = list
  description = "List of instance's names"
  default = ["rpx"]
}

variable "rpx_volume_data" {
  type        = number
  description = "Size of volume instance, if 0 no volume attached"
  default     = 0
}

variable "rpx_flavor" {
  type    = string
  default = "standard-pi-2.4"
}

variable "rpx_environment" {
  type = map(any)
  default = {}
}

variable "rpx_fixed_fip" {
  type = list
  default = ["10.224.169.168"]
}

##app1

variable "app1_image" {
  type    = string
  default = "debian12-mi-20260225"
}

variable "app1_public_access" {
  type    = bool
  default = false
}

variable "app1_volume_instance" {
  type    = number
  default = 20
}

variable "app1_list_instance" {
  type = list
  description = "List of instance's names"
  default = ["grist"]
}

variable "app1_volume_data" {
  type        = number
  description = "Size of volume instance, if 0 no volume attached"
  default     = 80
}

variable "app1_flavor" {
  type    = string
  default = "standard-pi-8.16"
}

variable "app1_environment" {
  type = map(any)
  default = {}
}

variable "app1_fixed_fip" {
  type = list
  default = []
}

##app2

variable "app2_image" {
  type    = string
  default = "debian12-mi-20260225"
}

variable "app2_public_access" {
  type    = bool
  default = true
}

variable "app2_volume_instance" {
  type    = number
  default = 20
}

variable "app2_list_instance" {
  type = list
  description = "List of instance's names"
  default = ["python"]
}

variable "app2_volume_data" {
  type        = number
  description = "Size of volume instance, if 0 no volume attached"
  default     = 80
}

variable "app2_flavor" {
  type    = string
  default = "standard-pi-1.2"
}

variable "app2_environment" {
  type = map(any)
  default = {}
}

variable "app2_fixed_fip" {
  type = list
  default = []
}

##DSD

variable "dsd_image" {
  type    = string
  default = "debian12-mi-20260225"
}

variable "dsd_public_access" {
  type    = bool
  default = false
}

variable "dsd_volume_instance" {
  type    = number
  default = 10
}

variable "dsd_list_instance" {
  type = list
  description = "List of instance's names"
  default = ["dsd1", "dsd2", "dsd3"]
}

variable "dsd_volume_data" {
  type        = number
  description = "Size of volume instance, if 0 no volume attached"
  default     = 0
}

variable "dsd_ip_address" {
  type = list(string)
  default = ["192.168.10.250", "192.168.10.251", "192.168.10.252"]
}

variable "dsd_flavor" {
  type    = string
  default = "standard-pi-1.1"
}

variable "dsd_environment" {
  type = map(any)
  default = {}
}

variable "dsd_fixed_fip" {
  type = list
  default = []
}

##VISU

variable "visu_image" {
  type    = string
  default = "debian12-mi-20260225"
}

variable "visu_public_access" {
  type    = bool
  default = false
}

variable "visu_volume_instance" {
  type    = number
  default = 10
}

variable "visu_list_instance" {
  type = list
  description = "List of instance's names"
  default = ["visu"]
}

variable "visu_volume_data" {
  type        = number
  description = "Size of volume instance, if 0 no volume attached"
  default     = 0
}

variable "visu_flavor" {
  type    = string
  default = "standard-pi-2.2"
}

variable "visu_environment" {
  type = map(any)
  default = {}
}

variable "visu_fixed_fip" {
  type = list
  default = []
}

##bdd_grist

variable "bdd_grist_image" {
  type    = string
  default = "debian12-mi-20260225"
}

variable "bdd_grist_public_access" {
  type    = bool
  default = false
}

variable "bdd_grist_volume_instance" {
  type    = number
  default = 20
}

variable "bdd_grist_list_instance" {
  type = list
  description = "List of instance's names"
  default = ["postgres"]
}

variable "bdd_grist_volume_data" {
  type        = number
  description = "Size of volume instance, if 0 no volume attached"
  default     = 80
}

variable "bdd_grist_flavor" {
  type    = string
  default = "standard-pi-2.4"
}

variable "bdd_grist_environment" {
  type = map(any)
  default = {}
}

variable "bdd_grist_fixed_fip" {
  type = list
  default = []
}

##bdd_flask

variable "bdd_flask_image" {
  type    = string
  default = "debian12-mi-20260225"
}

variable "bdd_flask_public_access" {
  type    = bool
  default = false
}

variable "bdd_flask_volume_instance" {
  type    = number
  default = 20
}

variable "bdd_flask_list_instance" {
  type = list
  description = "List of instance's names"
  default = ["postgres"]
}

variable "bdd_flask_volume_data" {
  type        = number
  description = "Size of volume instance, if 0 no volume attached"
  default     = 80
}

variable "bdd_flask_flavor" {
  type    = string
  default = "standard-pi-2.4"
}

variable "bdd_flask_environment" {
  type = map(any)
  default = {}
}

variable "bdd_flask_fixed_fip" {
  type = list
  default = []
}

##keycloak

variable "keycloak_image" {
  type    = string
  default = "debian12-mi-20260225"
}

variable "keycloak_public_access" {
  type    = bool
  default = false
}

variable "keycloak_volume_instance" {
  type    = number
  default = 10
}

variable "keycloak_list_instance" {
  type = list
  description = "List of instance's names"
  default = ["keycloak"]
}

variable "keycloak_volume_data" {
  type        = number
  description = "Size of volume instance, if 0 no volume attached"
  default     = 20
}

variable "keycloak_flavor" {
  type    = string
  default = "standard-pi-4.8"
}

variable "keycloak_environment" {
  type = map(any)
  default = {}
}

variable "keycloak_fixed_fip" {
  type = list
  default = []
}

##arp

variable "arp_image" {
  type    = string
  default = "debian12-mi-20260225"
}

variable "arp_public_access" {
  type    = bool
  default = true
}

variable "arp_volume_instance" {
  type    = number
  default = 10
}

variable "arp_list_instance" {
  type = list
  description = "List of instance's names"
  default = ["arp"]
}

variable "arp_volume_data" {
  type        = number
  description = "Size of volume instance, if 0 no volume attached"
  default     = 0
}

variable "arp_flavor" {
  type    = string
  default = "standard-pi-1.2"
}

variable "arp_environment" {
  type = map(any)
  default = {}
}

variable "arp_fixed_fip" {
  type = list
  default = ["10.224.171.89"]
}

## network

variable "ssh_keyname" {
  type    = string
  default = "dev"
}

variable "subnet_name" {
  type    = string
  default = "default"
}

variable "cidr" {
  type    = string
  default = "192.168.10.0/24"
}

variable "region" {
  type    = string
  default = "r1"
}

variable "segment_mi" {
  type = string
  default = null
}

