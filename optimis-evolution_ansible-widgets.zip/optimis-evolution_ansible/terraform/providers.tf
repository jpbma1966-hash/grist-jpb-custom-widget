provider "openstack" {
  auth_url    = "https://identity.r2.pi2.minint.fr"
  tenant_name        = var.tenant_name
  user_domain_name    = "tech"
  project_domain_name = "tech"
  region      = var.region_tenant
  cacert_file = "/etc/ssl/certs/ca-certificates.crt"
}

