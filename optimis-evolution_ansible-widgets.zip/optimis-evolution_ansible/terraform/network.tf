
module "network" {
  source          = "git::https://gitlab.forge-dc.cloudmi.minint.fr/entites/sdas/chae/applications/mutualis/terraform-modules.git//network?ref=1.0.5"
  cidr            = var.cidr
  region          = var.region
  prefix_project  = var.prefix_project
  ssh_keyname     = var.ssh_keyname
  segment_mi      = var.segment_mi
  start_dhcp_pool = 10
  end_dhcp_pool   = 99
  zone            = var.zone
  security_groups = {
      rpx = {
          description = "RPX SG"
          rules = [
              {
                  direction        = "ingress"
                  ethertype        = "IPv4"
                  protocol         = "tcp"
                  port_range_min   = 80
                  port_range_max   = 80
                  remote_ip_prefix = "0.0.0.0/0"
              },
              {
                  direction        = "ingress"
                  ethertype        = "IPv4"
                  protocol         = "tcp"
                  port_range_min   = 443
                  port_range_max   = 443
                  remote_ip_prefix = "0.0.0.0/0"
              }
          ]
      }
      app_grist = {
        description = "Grist"
        rules = [
          {
            direction        = "ingress"
            ethertype        = "IPv4"
            protocol         = "tcp"
            port_range_min   = 8484
            port_range_max   = 8484
            remote_group_name = "rpx"
          }
        ]
      }
      app_flask = {
        description = "Flask Python"
        rules = [
          {
            direction        = "ingress"
            ethertype        = "IPv4"
            protocol         = "tcp"
            port_range_min   = 8001
            port_range_max   = 8001
            remote_group_name = "arp"
          },
          {
            # site des widgets (rôle widgets_site) : le RPX le joint sous /plugin/
            direction        = "ingress"
            ethertype        = "IPv4"
            protocol         = "tcp"
            port_range_min   = 8080
            port_range_max   = 8080
            remote_group_name = "rpx"
          }
        ]
      }
      visu = {
          description = "visualisation des shema bdd"
          rules = [
              {
                  direction        = "ingress"
                  ethertype        = "IPv4"
                  protocol         = "tcp"
                  port_range_min   = 80
                  port_range_max   = 80
                  remote_group_name = "arp"
              }
          ]
      }
      redis = {
        description = "redis"
        rules = [
          { direction        = "ingress"
            ethertype        = "IPv4"
            protocol         = "tcp"
            port_range_min   = 6379
            port_range_max   = 6379
            remote_group_name = "App_Grist"
          }
        ]
      }
       bdd_flask = {
        description = "bdd de l'api"
        rules = [
          {
            direction        = "ingress"
            ethertype        = "IPv4"
            protocol         = "tcp"
            port_range_min   = 5432
            port_range_max   = 5432
            remote_group_name = "visu"
          },
          {
            direction        = "ingress"
            ethertype        = "IPv4"
            protocol         = "tcp"
            port_range_min   = 5432
            port_range_max   = 5432
            remote_group_name = "app_flask"
          }
        ]
      }
      bdd_grist = {
          description = "bdd grist"
          rules = [
          {
            direction        = "ingress"
            ethertype        = "IPv4"
            protocol         = "tcp"
            port_range_min   = 5432
            port_range_max   = 5432
            remote_group_name = "visu"
          },
          {
            direction        = "ingress"
            ethertype        = "IPv4"
            protocol         = "tcp"
            port_range_min   = 5432
            port_range_max   = 5432
            remote_group_name = "app_grist"
          }
          ]
      }
      pio = {
          description = "bastion du tenant"
          rules = [
              {
                direction        = "ingress"
                ethertype        = "IPv4"
                protocol         = "tcp"
                port_range_min   = 22
                port_range_max   = 22
                remote_ip_prefix = "0.0.0.0/0"
              }
          ]
      }
      dsd = {
            description = "consul"
            rules = [
              {
                direction        = "ingress"
                ethertype        = "IPv4"
                protocol         = "tcp"
                port_range_min   = 8300
                port_range_max   = 8300
                remote_ip_prefix = "192.168.10.0/24"
              }
            ]
        }
      keycloak = {
            description = "keycloak"
            rules = [
              {
                direction        = "ingress"
                ethertype        = "IPv4"
                protocol         = "tcp"
                port_range_min   = 8080
                port_range_max   = 8080
                remote_group_name = "app_grist"
              },
              {
                direction        = "ingress"
                ethertype        = "IPv4"
                protocol         = "tcp"
                port_range_min   = 8080
                port_range_max   = 8080
                remote_group_name = "rpx"
              }
            ]
        }
      arp = {
          description = "ARP SG"
          rules = [
              {
                  direction        = "ingress"
                  ethertype        = "IPv4"
                  protocol         = "tcp"
                  port_range_min   = 80
                  port_range_max   = 80
                  remote_ip_prefix = "0.0.0.0/0"
              },
              {
                  direction        = "ingress"
                  ethertype        = "IPv4"
                  protocol         = "tcp"
                  port_range_min   = 443
                  port_range_max   = 443
                  remote_ip_prefix = "0.0.0.0/0"
              }
          ]
      }
    global = {
            description = "générique"
            rules = [
              {
                direction        = "ingress"
                ethertype        = "IPv4"
                protocol         = "icmp"
                port_range_min   = null
                port_range_max   = null
                remote_ip_prefix = "0.0.0.0/0"
              },
              {
                direction        = "ingress"
                ethertype        = "IPv4"
                protocol         = "tcp"
                port_range_min   = 22
                port_range_max   = 22
                remote_group_name = "pio"
              },
              {
                direction        = "ingress"
                ethertype        = "IPv4"
                protocol         = "tcp"
                port_range_min   = 8301
                port_range_max   = 8301
                remote_ip_prefix = "192.168.10.0/24"
              },
              {
                direction        = "ingress"
                ethertype        = "IPv4"
                protocol         = "udp"
                port_range_min   = 8301
                port_range_max   = 8301
                remote_ip_prefix = "192.168.10.0/24"
              }
            ]
          }
    }
}



