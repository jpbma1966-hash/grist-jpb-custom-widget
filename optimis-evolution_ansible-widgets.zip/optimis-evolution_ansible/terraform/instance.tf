locals {
  instances = {
    pio = {
      flavor          = var.pio_flavor
      list_instance   = var.pio_list_instance
      image           = var.pio_image
      volume_instance = var.pio_volume_instance
      volume_data     = var.pio_volume_data
      public_access   = var.pio_public_access
      environment     = var.pio_environment
      security_group  = [module.network.security_groups.global, module.network.security_groups.pio]
      external_network = module.network.admin_network
      ip_address      = null
      fixed_fip        = var.pio_fixed_fip
    }
    redis = {
      flavor          = var.redis_flavor
      list_instance   = var.redis_list_instance
      image           = var.redis_image
      volume_instance = var.redis_volume_instance
      volume_data     = var.redis_volume_data
      public_access   = var.redis_public_access
      environment     = var.redis_environment
      security_group  = [module.network.security_groups.global, module.network.security_groups.redis]
      external_network = null
      ip_address       = null
      fixed_fip        = var.redis_fixed_fip
    }
    rpx = {
      flavor          = var.rpx_flavor
      list_instance   = var.rpx_list_instance
      image           = var.rpx_image
      volume_instance = var.rpx_volume_instance
      volume_data     = var.rpx_volume_data
      public_access   = var.rpx_public_access
      environment     = var.rpx_environment
      security_group  = [module.network.security_groups.global, module.network.security_groups.rpx]
      external_network = module.network.app_network
      ip_address      = null
      fixed_fip        = var.rpx_fixed_fip
    }
    grist = {
      flavor          = var.app1_flavor
      list_instance   = var.app1_list_instance
      image           = var.app1_image
      volume_instance = var.app1_volume_instance
      volume_data     = var.app1_volume_data
      public_access   = var.app1_public_access
      environment     = var.app1_environment
      security_group  = [module.network.security_groups.global, module.network.security_groups.app_grist]
      external_network = null
      ip_address      = null
      fixed_fip        = var.app1_fixed_fip
    }
    flask_python = {
      flavor          = var.app2_flavor
      list_instance   = var.app2_list_instance
      image           = var.app2_image
      volume_instance = var.app2_volume_instance
      volume_data     = var.app2_volume_data
      public_access   = var.app2_public_access
      environment     = var.app2_environment
      security_group  = [module.network.security_groups.global, module.network.security_groups.app_flask]
      external_network = module.network.service_network
      ip_address      = null
      fixed_fip        = var.app2_fixed_fip
    }
    dsd = {
      flavor          = var.dsd_flavor
      list_instance   = var.dsd_list_instance
      image           = var.dsd_image
      volume_instance = var.dsd_volume_instance
      volume_data     = var.dsd_volume_data
      public_access   = var.dsd_public_access
      environment     = var.dsd_environment
      security_group  = [module.network.security_groups.global, module.network.security_groups.dsd]
      external_network = null
      ip_address      = var.dsd_ip_address
      fixed_fip        = var.dsd_fixed_fip
    }
    visu = {
      flavor          = var.visu_flavor
      list_instance   = var.visu_list_instance
      image           = var.visu_image
      volume_instance = var.visu_volume_instance
      volume_data     = var.visu_volume_data
      public_access   = var.visu_public_access
      environment     = var.visu_environment
      security_group  = [module.network.security_groups.global, module.network.security_groups.visu]
      external_network = null
      ip_address      = null
      fixed_fip        = var.visu_fixed_fip

    }
    bdd_grist = {
      flavor          = var.bdd_grist_flavor
      list_instance   = var.bdd_grist_list_instance
      image           = var.bdd_grist_image
      volume_instance = var.bdd_grist_volume_instance
      volume_data     = var.bdd_grist_volume_data
      public_access   = var.bdd_grist_public_access
      environment     = var.bdd_grist_environment
      security_group  = [module.network.security_groups.global, module.network.security_groups.bdd_grist]
      external_network = null
      ip_address      = null
      fixed_fip        = var.bdd_grist_fixed_fip
    }
    bdd_flask = {
      flavor          = var.bdd_flask_flavor
      list_instance   = var.bdd_flask_list_instance
      image           = var.bdd_flask_image
      volume_instance = var.bdd_flask_volume_instance
      volume_data     = var.bdd_flask_volume_data
      public_access   = var.bdd_flask_public_access
      environment     = var.bdd_flask_environment
      security_group  = [module.network.security_groups.global, module.network.security_groups.bdd_flask]
      external_network = null
      ip_address      = null
      fixed_fip        = var.bdd_flask_fixed_fip
    }
    keycloak = {
      flavor          = var.keycloak_flavor
      list_instance   = var.keycloak_list_instance
      image           = var.keycloak_image
      volume_instance = var.keycloak_volume_instance
      volume_data     = var.keycloak_volume_data
      public_access   = var.keycloak_public_access
      environment     = var.keycloak_environment
      security_group  = [module.network.security_groups.global, module.network.security_groups.keycloak]
      external_network = null
      ip_address       = null
      fixed_fip        = var.keycloak_fixed_fip
    }
    arp = {
      flavor          = var.arp_flavor
      list_instance   = var.arp_list_instance
      image           = var.arp_image
      volume_instance = var.arp_volume_instance
      volume_data     = var.arp_volume_data
      public_access   = var.arp_public_access
      environment     = var.arp_environment
      security_group  = [module.network.security_groups.global, module.network.security_groups.arp]
      external_network = module.network.app_network
      ip_address      = null
      fixed_fip        = var.arp_fixed_fip
    }
  }
}

module "instances" {
  for_each = local.instances
  source   = "git::https://gitlab.forge-dc.cloudmi.minint.fr/entites/sdas/chae/applications/mutualis/terraform-modules.git//instance?ref=main"

  prefix_project   = var.prefix_project
  type_instance    = each.key
  flavor           = each.value.flavor
  list_instance    = each.value.list_instance
  image            = each.value.image
  volume_instance  = each.value.volume_instance
  volume_data      = each.value.volume_data
  volume_type      = var.volume_type
  volume_data_type = var.volume_data_type
  public_access    = each.value.public_access
  environment      = each.value.environment
  security_group   = each.value.security_group
  zone             = var.zone
  ip_address       = each.value.ip_address
  fixed_fip        = each.value.fixed_fip

  dns_ip           = module.network.dns_ip
  network_id       = module.network.network_id
  subnet_id        = module.network.subnet_id
  keypair_id       = module.network.keypair_id
  external_network = each.value.external_network
  ssh_public_keys  = var.ssh_public_keys

  depends_on = [
    module.network
  ]
}

output "public_ips" {
  value = {
    for k, m in module.instances :
    k => m.public_ip
  }
}


