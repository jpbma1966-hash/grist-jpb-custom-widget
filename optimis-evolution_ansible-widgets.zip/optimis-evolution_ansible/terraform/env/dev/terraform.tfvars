env                    = "dev"
region                 = "r2"
region_tenant          = "region2"
tenant_name            = "optimis-1fb2-opt-dev"
prefix_project         = "opt"
##pio
##rpx
##network
ssh_keyname            = "optimis-ssh"
#rpx


