#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Synchronisation du site des widgets Grist et des bibliothèques JavaScript.

Lit deux fichiers JSON (widgets.json, bibjs.json), télécharge tout ce qu'ils décrivent (par le proxy
authentifiant si des identifiants sont fournis), met le site à jour sous <root>/www et régénère
<root>/www/manifest.json (la liste lue par Grist).

Rien d'autre que la bibliothèque standard de Python 3 : ce script tourne tel quel sur le serveur.

Disposition (root = /opt/widgets-site) :
  www/                      servi par nginx (manifest.json, widget/, bibjs/)
  sync/widgets.json         ce qu'il faut télécharger : widgets
  sync/bibjs.json           ce qu'il faut télécharger : bibliothèques JS
  sync/manifest.manual.json widgets déclarés à la main (variable Ansible widgets_manifest)
  sync/credentials.json     proxy et identifiants (droits 0600), facultatif
  sync/state.json          fichiers gérés par ce script (pour supprimer ce qui n'existe plus)
  sync/report.json          compte rendu de la dernière exécution

Les fichiers de www/ qui ne viennent pas de ce script (widgets déposés à la main) ne sont jamais
modifiés ni supprimés.
"""
import argparse
import fnmatch
import hashlib
import json
import os
import re
import shutil
import ssl
import sys
import tarfile
import time
import urllib.error
import urllib.request
import zipfile
from urllib.parse import quote, unquote, urljoin, urlsplit

UA = 'optimis-widgets-sync/1.0'
TEXT_EXT = ('.html', '.htm', '.css', '.js', '.mjs')
EXT_BY_TYPE = {
    'text/css': '.css', 'text/javascript': '.js', 'application/javascript': '.js', 'application/x-javascript': '.js',
    'text/html': '.html', 'application/json': '.json', 'image/svg+xml': '.svg', 'image/png': '.png', 'image/jpeg': '.jpg',
    'image/gif': '.gif', 'image/webp': '.webp', 'image/x-icon': '.ico', 'font/woff2': '.woff2', 'font/woff': '.woff',
    'font/ttf': '.ttf', 'application/font-woff2': '.woff2', 'application/font-woff': '.woff',
}

TAG = re.compile(r'<(script|link|img|source|video|audio)\b([^>]*)>', re.I | re.S)
ATTR = re.compile(r'(\s)(src|href|data-src|poster)\s*=\s*("([^"]*)"|\'([^\']*)\')', re.I)
LINK_REL = re.compile(r'\brel\s*=\s*["\']?[^"\'>]*\b(stylesheet|icon|preload|modulepreload|manifest)\b', re.I)
SCRIPT_BODY = re.compile(r'(<script\b[^>]*>)(.*?)(</script\s*>)', re.I | re.S)
STYLE_BODY = re.compile(r'(<style\b[^>]*>)(.*?)(</style\s*>)', re.I | re.S)
CSS_URL = re.compile(r'url\(\s*(["\']?)([^)"\']+)\1\s*\)')
CSS_IMPORT = re.compile(r'@import\s+(["\'])([^"\']+)\1')
JS_IMPORT = re.compile(r'''((?:\bimport\b\s*(?:[\w*${},\s]+?\bfrom\s*)?|\bexport\b\s*(?:\*|\{[^}]*\})\s*from\s*|\bimport\s*\(\s*))(["'])((?:\.{1,2}/|/)[^"']+)\2''')
URL_LITERAL = re.compile(r'''https?://[^\s'"`<>()\\]+''')


class SyncError(Exception):
    pass


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def host_match(netloc, patterns):
    netloc = netloc.lower()
    host = netloc.split(':')[0]
    return any(fnmatch.fnmatch(netloc, p.lower()) or fnmatch.fnmatch(host, p.lower()) for p in patterns)


class Fetcher:
    """Téléchargements : par le proxy (avec identifiants) sauf pour les hôtes exclus."""

    def __init__(self, proxy=None, no_proxy=(), cafile=None, timeout=30, retries=3, max_bytes=30 * 1024 * 1024):
        context = ssl.create_default_context(cafile=cafile) if cafile else ssl.create_default_context()
        https = urllib.request.HTTPSHandler(context=context)
        self.direct = urllib.request.build_opener(urllib.request.ProxyHandler({}), https)
        self.proxied = urllib.request.build_opener(urllib.request.ProxyHandler({'http': proxy, 'https': proxy}), https) if proxy else None
        self.no_proxy = [h.strip().lower() for h in no_proxy if h.strip()]
        self.timeout, self.retries, self.max_bytes = timeout, retries, max_bytes

    def opener(self, url):
        host = (urlsplit(url).hostname or '').lower()
        if self.proxied and not any(host == n.lstrip('.') or host.endswith('.' + n.lstrip('.')) for n in self.no_proxy):
            return self.proxied
        return self.direct

    def get(self, url):
        last = None
        for attempt in range(self.retries):
            try:
                request = urllib.request.Request(url, headers={'User-Agent': UA, 'Accept': '*/*'})
                with self.opener(url).open(request, timeout=self.timeout) as response:
                    data = response.read(self.max_bytes + 1)
                    if len(data) > self.max_bytes:
                        raise SyncError('fichier trop gros (%d octets max)' % self.max_bytes)
                    return data, (response.headers.get('Content-Type') or '').split(';')[0].strip().lower(), response.geturl()
            except urllib.error.HTTPError as e:
                if e.code == 407:
                    raise SyncError('proxy : authentification refusée (407), vérifier les identifiants')
                if e.code < 500:
                    raise SyncError('HTTP %d' % e.code)
                last = SyncError('HTTP %d' % e.code)
            except SyncError:
                raise
            except Exception as e:  # réseau, délai, TLS
                last = SyncError(str(getattr(e, 'reason', e)))
            time.sleep(1 + attempt * 2)
        raise last or SyncError('échec')


class Mirror:
    def __init__(self, root, base_url, grist_origin, config, libs, manual, fetcher, force=False):
        self.root = root
        self.www = os.path.join(root, 'www')
        self.sync = os.path.join(root, 'sync')
        self.stage = os.path.join(root, '.staging')
        self.base_url = base_url.rstrip('/')
        self.fetcher, self.force = fetcher, force
        settings = config.get('settings', {})
        self.config, self.libs, self.manual = config, libs, manual
        self.widget_hosts = settings.get('widget_hosts', [])
        self.external_hosts = settings.get('external_hosts', [])
        self.max_files = int(settings.get('max_files', 5000))
        fill = lambda s: s.replace('{GRIST_ORIGIN}', grist_origin.rstrip('/')).replace('{BASE_URL}', self.base_url)
        self.rewrites = {k.split('#')[0]: fill(v) for k, v in settings.get('rewrites', {}).items()}
        self.libmap = {}
        self.files = {}      # chemin relatif -> sha256 (fichiers de cette exécution)
        self.done = {}       # clé d'URL -> chemin relatif (ou None : échec)
        self.warnings, self.errors, self.unresolved = [], [], set()
        self.downloaded = 0
        self.entries = []    # entrées du manifest issues des téléchargements
        self.state = self.load_json(os.path.join(self.sync, 'state.json'), {})
        self.previous = set(self.state.get('managed', []))

    # ----- utilitaires -----
    @staticmethod
    def load_json(path, default):
        try:
            with open(path, encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            return default
        except ValueError as e:
            raise SyncError('JSON illisible : %s (%s)' % (path, e))

    def warn(self, text):
        self.warnings.append(text)
        print('AVERTISSEMENT :', text, file=sys.stderr)

    def error(self, text):
        self.errors.append(text)
        print('ERREUR :', text, file=sys.stderr)

    def local_url(self, rel):
        return self.base_url + '/' + quote(rel, safe="/@~+=,()-._")

    def local_rel(self, url, kind, ctype=None):
        u = urlsplit(url)
        host = re.sub(r'[^a-z0-9.\-_]', '_', u.netloc.lower())
        path = unquote(u.path) or '/'
        if path.endswith('/'):
            path += 'index.html'
        segments = [s for s in path.split('/') if s not in ('', '.')]
        if any(s == '..' for s in segments):
            raise SyncError('chemin interdit : %s' % url)
        segments = [re.sub(r'[^A-Za-z0-9._@~+=,()\-]', '_', s)[:120] for s in segments] or ['index.html']
        name = segments[-1]
        stem, ext = os.path.splitext(name)
        if kind != 'widget' and u.query:
            stem += '__' + hashlib.md5(u.query.encode()).hexdigest()[:8]
        if not ext and ctype in EXT_BY_TYPE:
            ext = EXT_BY_TYPE[ctype]
        segments[-1] = stem + ext
        prefix = 'widget' if kind == 'widget' else 'bibjs/ext'
        return '%s/%s/%s' % (prefix, host, '/'.join(segments))

    def put(self, rel, data):
        path = os.path.join(self.stage, rel)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'wb') as f:
            f.write(data)
        self.files[rel] = sha256(data)

    def keep_previous(self, rel):
        """Un téléchargement échoue : le fichier précédent (géré par ce script) est conservé."""
        old = os.path.join(self.www, rel)
        if rel in self.previous and os.path.isfile(old):
            with open(old, 'rb') as f:
                self.put(rel, f.read())
            return True
        return False

    # ----- téléchargement d'un fichier et de ses dépendances -----
    def get_asset(self, url, kind):
        url = url.split('#')[0]
        if kind == 'widget':
            url = url.split('?')[0]
        key = (kind, url)
        if key in self.done:
            return self.done[key]
        if len(self.files) >= self.max_files:
            self.warn('limite de %d fichiers atteinte, %s ignoré' % (self.max_files, url))
            return None
        self.done[key] = None
        try:
            data, ctype, final = self.fetcher.get(url)
        except SyncError as e:
            rel = self.local_rel(url, kind)
            if self.keep_previous(rel):
                self.warn('%s : %s (version précédente conservée)' % (url, e))
                self.done[key] = rel
                return rel
            self.error('%s : %s' % (url, e))
            return None
        self.downloaded += 1
        rel = self.local_rel(url, kind, ctype)
        self.done[key] = rel
        self.put(rel, self.process(url, rel, data))
        return rel

    # ----- réécriture -----
    def process(self, url, rel, data):
        if not rel.lower().endswith(TEXT_EXT):
            return data
        try:
            text = data.decode('utf-8')
        except UnicodeDecodeError:
            return data
        ext = os.path.splitext(rel)[1].lower()
        if ext in ('.html', '.htm'):
            text = self.process_html(text, url)
        elif ext == '.css':
            text = self.process_css(text, url)
        else:
            text = self.process_js(text, url)
        return text.encode('utf-8')

    def resolve(self, raw, base):
        """Renvoie le texte de remplacement d'une référence (ou None : on ne touche à rien)."""
        raw = raw.strip()
        if not raw or raw.startswith(('#', 'data:', 'javascript:', 'mailto:', 'blob:', 'about:')) or '${' in raw or '{{' in raw:
            return None
        absolute = urljoin(base, raw) if base else raw
        if not re.match(r'https?://', absolute, re.I):
            return None
        fragment = ('#' + absolute.split('#', 1)[1]) if '#' in absolute else ''
        clean = absolute.split('#')[0]
        bare = clean.split('?')[0]  # « lib.js?v=3 » retrouve la bibliothèque déclarée sans paramètre
        fixed = self.rewrites.get(clean) or self.libmap.get(clean) or self.rewrites.get(bare) or self.libmap.get(bare)
        if fixed:
            return fixed + fragment
        netloc = urlsplit(clean).netloc
        if host_match(netloc, self.widget_hosts):
            kind = 'widget'
        elif host_match(netloc, self.external_hosts):
            kind = 'ext'
        else:
            self.unresolved.add(clean)
            return None
        rel = self.get_asset(clean, kind)
        if rel is None:
            return None
        relative = bool(base) and not re.match(r'^(?:[a-z][a-z0-9+.\-]*:)?//', raw, re.I) and not raw.startswith('/')
        if kind == 'widget' and relative:
            return None  # l'arborescence d'origine est conservée : le lien relatif reste valable
        return self.local_url(rel) + fragment

    def process_css(self, text, base):
        def url(m):
            new = self.resolve(m.group(2), base)
            return m.group(0) if new is None else 'url(%s%s%s)' % (m.group(1), new, m.group(1))

        def imp(m):
            new = self.resolve(m.group(2), base)
            return m.group(0) if new is None else '@import %s%s%s' % (m.group(1), new, m.group(1))
        return CSS_IMPORT.sub(imp, CSS_URL.sub(url, text))

    def process_js(self, text, base):
        def imp(m):
            new = self.resolve(m.group(3), base)
            return m.group(0) if new is None else '%s%s%s%s' % (m.group(1), m.group(2), new, m.group(2))

        def literal(m):
            new = self.resolve(m.group(0), base)
            return m.group(0) if new is None else new
        return URL_LITERAL.sub(literal, JS_IMPORT.sub(imp, text))

    def process_html(self, text, base):
        def tag(m):
            name, attrs = m.group(1), m.group(2)
            if name.lower() == 'link' and not LINK_REL.search(attrs):
                return m.group(0)
            changed = []

            def attr(a):
                quote_char = a.group(3)[0]
                value = a.group(4) if a.group(4) is not None else a.group(5)
                new = self.resolve(value, base)
                if new is None or new == value:
                    return a.group(0)
                changed.append(1)
                return '%s%s=%s%s%s' % (a.group(1), a.group(2), quote_char, new, quote_char)
            attrs = ATTR.sub(attr, attrs)
            if changed:  # le contenu a pu changer : l'empreinte d'intégrité ne vaut plus
                attrs = re.sub(r'\s(integrity|crossorigin)\s*=\s*("[^"]*"|\'[^\']*\')', '', attrs, flags=re.I)
            return '<%s%s>' % (name, attrs)
        text = TAG.sub(tag, text)
        text = SCRIPT_BODY.sub(lambda m: m.group(1) + self.process_js(m.group(2), base) + m.group(3), text)
        return STYLE_BODY.sub(lambda m: m.group(1) + self.process_css(m.group(2), base) + m.group(3), text)

    # ----- bibliothèques JS déclarées -----
    def fetch_libs(self):
        for lib in self.libs.get('libs', []):
            for item in lib.get('files', []):
                url, dest = item.get('url', ''), item.get('dest', '')
                if not url or not dest or '..' in dest.split('/') or dest.startswith('/'):
                    self.error('bibjs.json : entrée invalide pour %s' % lib.get('name', '?'))
                    continue
                rel = 'bibjs/' + dest
                try:
                    data, _, _ = self.fetcher.get(url)
                except SyncError as e:
                    if self.keep_previous(rel):
                        self.warn('%s : %s (version précédente conservée)' % (url, e))
                        self.register_lib(url, item, rel)
                    else:
                        self.error('%s : %s' % (url, e))
                    continue
                self.downloaded += 1
                digest = sha256(data)
                wanted = (item.get('sha256') or '').lower()
                if wanted and wanted != digest:
                    self.error('%s : empreinte sha256 différente de celle attendue (%s)' % (url, digest))
                    continue
                if not wanted:
                    self.warn('%s : pas de sha256 dans bibjs.json (calculé : %s)' % (url, digest))
                self.register_lib(url, item, rel)
                self.put(rel, self.process(url, rel, data))

    def register_lib(self, url, item, rel):
        target = self.local_url(rel)
        for u in [url] + list(item.get('aliases', [])):
            self.libmap[u.split('#')[0]] = target

    # ----- archives -----
    def fetch_archive(self, item):
        ident, url = item.get('id', ''), item.get('url', '')
        if not re.match(r'^[A-Za-z0-9._-]+$', ident) or not url:
            self.error('widgets.json : archive invalide (%r)' % item)
            return
        try:
            data, _, _ = self.fetcher.get(url)
        except SyncError as e:
            self.error('%s : %s' % (url, e))
            return
        self.downloaded += 1
        tmp = os.path.join(self.root, '.archive.tmp')
        with open(tmp, 'wb') as f:
            f.write(data)
        strip, subdir = int(item.get('strip', 0)), item.get('subdir', '').strip('/')
        count = 0
        try:
            for name, read in self.archive_members(tmp):
                parts = [p for p in name.split('/') if p not in ('', '.')]
                if '..' in parts or name.startswith('/'):
                    continue
                parts = parts[strip:]
                if subdir:
                    sub = subdir.split('/')
                    if parts[:len(sub)] != sub:
                        continue
                    parts = parts[len(sub):]
                if not parts:
                    continue
                if count >= self.max_files:
                    self.warn('archive %s : limite de fichiers atteinte' % ident)
                    break
                rel = 'widget/%s/%s' % (ident, '/'.join(re.sub(r'[^A-Za-z0-9._@~+=,()\-]', '_', p) for p in parts))
                self.put(rel, self.process(None, rel, read()))
                count += 1
        except (zipfile.BadZipFile, tarfile.TarError) as e:
            self.error('%s : archive illisible (%s)' % (url, e))
        finally:
            os.remove(tmp)

    @staticmethod
    def archive_members(path):
        if zipfile.is_zipfile(path):
            z = zipfile.ZipFile(path)
            for info in z.infolist():
                if not info.is_dir():
                    yield info.filename, (lambda i=info: z.read(i))
        else:
            t = tarfile.open(path)
            for member in t.getmembers():
                if member.isfile():
                    yield member.name, (lambda m=member: t.extractfile(m).read())

    # ----- widgets et manifest -----
    def selected(self, widget, spec):
        names = [str(widget.get(k, '')) for k in ('widgetId', 'name')]
        match = lambda patterns: any(fnmatch.fnmatch(n.lower(), p.lower()) for n in names for p in patterns)
        if spec.get('include') and not match(spec['include']):
            return False
        return not (spec.get('exclude') and match(spec['exclude']))

    def load_list(self, spec):
        if spec.get('file'):
            return self.load_json(os.path.join(self.sync, spec['file']), [])
        data, _, _ = self.fetcher.get(spec['url'])
        return json.loads(data.decode('utf-8'))

    def add_widget(self, entry, page_url):
        """Télécharge la page d'un widget (et ses dépendances) ; l'entrée du manifest pointe sur la copie."""
        rel = self.get_asset(page_url, 'widget')
        if rel is None:
            return False
        new = dict(entry)
        new['url'] = self.local_url(rel)
        self.entries.append(new)
        return True

    def run_widgets(self):
        for spec in self.config.get('archives', []):
            self.fetch_archive(spec)
        for spec in self.config.get('manifests', []):
            where = spec.get('url') or spec.get('file') or '?'
            try:
                items = self.load_list(spec)
                if isinstance(items, dict):
                    items = items.get('widgets', [])
            except (SyncError, ValueError) as e:
                self.error('liste de widgets %s : %s' % (where, e))
                continue
            for w in items:
                if not isinstance(w, dict) or not w.get('url') or not self.selected(w, spec):
                    continue
                page = urljoin(spec['url'], w['url']) if spec.get('url') else w['url']
                if not host_match(urlsplit(page).netloc, self.widget_hosts):
                    self.warn('widget %s ignoré : hôte %s absent de widget_hosts' % (w.get('name', page), urlsplit(page).netloc))
                    continue
                self.add_widget({k: v for k, v in w.items() if k != 'url'}, page)
        for w in self.config.get('widgets', []):
            meta = {k: v for k, v in w.items() if k not in ('url', 'archive', 'entry')}
            if w.get('archive'):
                rel = 'widget/%s/%s' % (w['archive'], w.get('entry', 'index.html').lstrip('/'))
                if rel in self.files:
                    meta['url'] = self.local_url(rel)
                    self.entries.append(meta)
                else:
                    self.error('widget %s : fichier %s absent de l\'archive %s' % (w.get('name', '?'), w.get('entry'), w['archive']))
            elif w.get('url'):
                if not host_match(urlsplit(w['url']).netloc, self.widget_hosts):
                    self.warn('widget %s ignoré : hôte %s absent de widget_hosts' % (w.get('name', w['url']), urlsplit(w['url']).netloc))
                    continue
                self.add_widget(meta, w['url'])
            else:
                self.error('widgets.json : widget sans url ni archive (%r)' % w)

    def build_manifest(self):
        seen, manifest = set(), []
        for entry in list(self.manual) + self.entries:
            key = entry.get('widgetId') or entry.get('url')
            if key in seen:
                continue
            seen.add(key)
            manifest.append(entry)
        return manifest

    # ----- publication -----
    def publish(self, manifest, dry_run=False):
        changed = removed = 0
        if dry_run:
            return changed, removed
        for rel in sorted(self.files):
            dst = os.path.join(self.www, rel)
            if os.path.exists(dst):
                if rel not in self.previous and not self.force:
                    self.warn('%s existe déjà et n\'est pas géré par la synchronisation : conservé' % rel)
                    continue
                with open(dst, 'rb') as f:
                    if sha256(f.read()) == self.files[rel]:
                        continue
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            tmp = dst + '.sync-tmp'
            shutil.copyfile(os.path.join(self.stage, rel), tmp)
            os.replace(tmp, dst)
            changed += 1
        for rel in sorted(self.previous - set(self.files)):
            dst = os.path.join(self.www, rel)
            if os.path.isfile(dst):
                os.remove(dst)
                removed += 1
                folder = os.path.dirname(dst)
                while folder != self.www and os.path.isdir(folder) and not os.listdir(folder):
                    os.rmdir(folder)
                    folder = os.path.dirname(folder)
        text = json.dumps(manifest, indent=2, ensure_ascii=False) + '\n'
        target = os.path.join(self.www, 'manifest.json')
        old = open(target, encoding='utf-8').read() if os.path.exists(target) else None
        if old != text:
            tmp = target + '.sync-tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                f.write(text)
            os.replace(tmp, target)
            changed += 1
        with open(os.path.join(self.sync, 'state.json'), 'w', encoding='utf-8') as f:
            json.dump({'managed': sorted(self.files), 'updated': time.strftime('%Y-%m-%dT%H:%M:%S')}, f, indent=1)
        return changed, removed


def read_credentials(path):
    try:
        with open(path, encoding='utf-8') as f:
            c = json.load(f)
    except FileNotFoundError:
        return None, [], None
    host = (c.get('host') or '').strip()
    if not host:
        return None, c.get('no_proxy', []), c.get('ca_bundle') or None
    user, password = c.get('user'), c.get('password')
    scheme = 'http://'
    auth = '%s:%s@' % (quote(user, safe=''), quote(password or '', safe='')) if user else ''
    return scheme + auth + host, c.get('no_proxy', []), c.get('ca_bundle') or None


def main(argv=None):
    p = argparse.ArgumentParser(description='Synchronise les widgets Grist et les bibliothèques JS.')
    p.add_argument('--root', default='/opt/widgets-site')
    p.add_argument('--base-url', required=True, help='adresse publique du site, ex. http://hôte/plugin')
    p.add_argument('--grist-origin', required=True, help='adresse de Grist, ex. http://hôte')
    p.add_argument('--credentials', help='défaut : <root>/sync/credentials.json')
    p.add_argument('--dry-run', action='store_true', help='télécharge et contrôle, sans modifier le site')
    p.add_argument('--force', action='store_true', help='écrase aussi les fichiers qui ne viennent pas de la synchronisation')
    args = p.parse_args(argv)
    sync = os.path.join(args.root, 'sync')
    started = time.strftime('%Y-%m-%dT%H:%M:%S')
    try:
        config = Mirror.load_json(os.path.join(sync, 'widgets.json'), {})
        libs = Mirror.load_json(os.path.join(sync, 'bibjs.json'), {})
        manual = Mirror.load_json(os.path.join(sync, 'manifest.manual.json'), [])
        proxy, no_proxy, cafile = read_credentials(args.credentials or os.path.join(sync, 'credentials.json'))
        fetcher = Fetcher(proxy, no_proxy, cafile, timeout=int(config.get('settings', {}).get('timeout', 30)))
        mirror = Mirror(args.root, args.base_url, args.grist_origin, config, libs, manual, fetcher, args.force)
        shutil.rmtree(mirror.stage, ignore_errors=True)
        os.makedirs(mirror.stage)
        os.makedirs(mirror.www, exist_ok=True)
        mirror.fetch_libs()
        mirror.run_widgets()
        if mirror.errors and mirror.downloaded == 0:
            raise SyncError('aucun téléchargement n\'a réussi (réseau ou proxy ?) : le site n\'est pas modifié')
        manifest = mirror.build_manifest()
        changed, removed = mirror.publish(manifest, args.dry_run)
    except SyncError as e:
        print('SYNC: ÉCHEC - %s' % e, file=sys.stderr)
        return 3
    finally:
        shutil.rmtree(os.path.join(args.root, '.staging'), ignore_errors=True)
    report = {
        'started': started, 'finished': time.strftime('%Y-%m-%dT%H:%M:%S'), 'dry_run': args.dry_run,
        'files': len(mirror.files), 'downloaded': mirror.downloaded, 'changed': changed, 'removed': removed,
        'widgets': [w.get('name') or w.get('url') for w in mirror.entries],
        'warnings': mirror.warnings, 'errors': mirror.errors, 'external_not_copied': sorted(mirror.unresolved),
    }
    os.makedirs(sync, exist_ok=True)
    with open(os.path.join(sync, 'report.json'), 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    print('SYNC: %s fichiers=%d modifies=%d supprimes=%d widgets=%d avertissements=%d erreurs=%d' % (
        'ok' if not mirror.errors else 'partiel', len(mirror.files), changed, removed, len(mirror.entries), len(mirror.warnings), len(mirror.errors)))
    return 0 if not mirror.errors else 1


if __name__ == '__main__':
    sys.exit(main())
