"""Test de bout en bout de widgets_sync.py avec de faux serveurs (site, CDN) et un proxy authentifié.
Lancer :  python3 tests/test_widgets_sync.py
"""
import base64, http.server, io, json, os, shutil, subprocess, sys, tempfile, threading, unittest, urllib.request, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPT = os.path.join(HERE, '..', 'files', 'widgets_sync.py')
USER, PASSWORD = 'cg_test', 'p@ss:w/rd é'


def serve(handler):
    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server


def static_handler(routes):
    class H(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def do_GET(self):
            path = self.path.split('?')[0]
            if path in routes:
                body, ctype = routes[path]
                body = body if isinstance(body, bytes) else body.encode('utf-8')
                self.send_response(200); self.send_header('Content-Type', ctype); self.send_header('Content-Length', str(len(body))); self.end_headers(); self.wfile.write(body)
            else:
                self.send_response(404); self.end_headers()
    return H


class ProxyHandler(http.server.BaseHTTPRequestHandler):
    wanted = 'Basic ' + base64.b64encode(('%s:%s' % (USER, PASSWORD)).encode()).decode()
    seen = []
    def log_message(self, *a): pass
    def do_GET(self):
        if self.headers.get('Proxy-Authorization') != self.wanted:
            self.send_response(407); self.send_header('Proxy-Authenticate', 'Basic realm="proxy"'); self.send_header('Content-Length', '0'); self.end_headers(); return
        ProxyHandler.seen.append(self.path)
        try:
            with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(self.path, timeout=10) as r:
                body = r.read(); ctype = r.headers.get('Content-Type', 'application/octet-stream')
            self.send_response(200); self.send_header('Content-Type', ctype); self.send_header('Content-Length', str(len(body))); self.end_headers(); self.wfile.write(body)
        except urllib.error.HTTPError as e:
            self.send_response(e.code); self.send_header('Content-Length', '0'); self.end_headers()


class SyncTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cdn = serve(static_handler({}))
        cdn = cls.cdn_host = '127.0.0.1:%d' % cls.cdn.server_port
        cls.cdn.RequestHandlerClass = static_handler({
            '/lib/lib.min.js': ('window.lib = 1;', 'text/javascript'),
            '/fonts/f.woff2': (b'FONTDATA', 'font/woff2'),
            '/css2': ('@font-face{font-family:X;src:url(http://%s/fonts/f.woff2)}' % cdn, 'text/css'),
        })
        page = ('<html><head><script src="https://docs.getgrist.com/grist-plugin-api.js"></script>'
                '<script src="cal.js"></script><script src="/w/common/util.js"></script><link rel="stylesheet" href="style.css">'
                '<script src="http://CDN/lib/lib.min.js?v=1" integrity="sha384-xxx" crossorigin="anonymous"></script>'
                '<link rel="stylesheet" href="http://CDN/css2?family=X"><a href="http://CDN/docs">lien</a></head>'
                '<body><img src="logo.png"><script>var u="http://CDN/lib/lib.min.js?v=1";</script></body></html>').replace('CDN', cdn)
        cls.routes = {
            '/w/cal/index.html': (page, 'text/html'),
            '/w/cal/cal.js': ("import {x} from './mod.js';\nconsole.log(x);", 'text/javascript'),
            '/w/cal/mod.js': ('export const x = 1;', 'text/javascript'),
            '/w/common/util.js': ('var util = 1;', 'text/javascript'),
            '/w/cal/style.css': ('body{background:url(bg.png)} @import "extra.css";', 'text/css'),
            '/w/cal/extra.css': ('.a{color:red}', 'text/css'),
            '/w/cal/bg.png': (b'PNG1', 'image/png'),
            '/w/cal/logo.png': (b'PNG2', 'image/png'),
            '/w/other/index.html': ('<html><body>autre</body></html>', 'text/html'),
        }
        cls.site = serve(static_handler(cls.routes))
        cls.site_host = '127.0.0.1:%d' % cls.site.server_port
        cls.routes['/manifest.json'] = (json.dumps([
            {'name': 'Calendrier', 'widgetId': 'cal', 'url': 'http://%s/w/cal/index.html' % cls.site_host, 'accessLevel': 'read table', 'published': True},
            {'name': 'Autre', 'widgetId': 'other', 'url': 'http://%s/w/other/index.html' % cls.site_host, 'accessLevel': 'none'},
            {'name': 'Distant', 'widgetId': 'remote', 'url': 'http://localhost:9/x/index.html'},
        ]), 'application/json')
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w') as z:
            z.writestr('top/public/wid/index.html', '<script src="http://%s/lib/lib.min.js?v=1"></script>archive' % cdn)
            z.writestr('top/public/wid/app.js', 'x')
            z.writestr('top/other/skip.txt', 'x')
            z.writestr('../evil.txt', 'x')
        cls.routes['/arch.zip'] = (buf.getvalue(), 'application/zip')
        cls.proxy = serve(ProxyHandler)

    @classmethod
    def tearDownClass(cls):
        for s in (cls.cdn, cls.site, cls.proxy):
            s.shutdown()

    def setUp(self):
        self.root = tempfile.mkdtemp()
        self.sync = os.path.join(self.root, 'sync'); os.makedirs(self.sync)
        self.write('widgets.json', {
            'settings': {'widget_hosts': [self.site_host], 'external_hosts': [self.cdn_host],
                         'rewrites': {'https://docs.getgrist.com/grist-plugin-api.js': '{GRIST_ORIGIN}/grist-plugin-api.js'}},
            'manifests': [{'url': 'http://%s/manifest.json' % self.site_host, 'exclude': ['other']}],
            'archives': [{'id': 'arch', 'url': 'http://%s/arch.zip' % self.site_host, 'strip': 1, 'subdir': 'public'}],
            'widgets': [{'name': 'Archive', 'widgetId': 'arch', 'archive': 'arch', 'entry': 'wid/index.html', 'accessLevel': 'none'}],
        })
        self.write('bibjs.json', {'libs': [{'name': 'jszip', 'files': [
            {'url': 'http://%s/lib/lib.min.js' % self.cdn_host, 'dest': 'lib-1.0/lib.min.js'}]}]})
        self.write('manifest.manual.json', [{'name': 'Manuel', 'widgetId': 'manuel', 'url': 'http://front/plugin/widget/manuel/index.html'}])
        self.write('credentials.json', {'host': '127.0.0.1:%d' % self.proxy.server_port, 'user': USER, 'password': PASSWORD})
        ProxyHandler.seen.clear()

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def write(self, name, data):
        with open(os.path.join(self.sync, name), 'w', encoding='utf-8') as f:
            json.dump(data, f)

    def run_sync(self, *extra):
        p = subprocess.run([sys.executable, SCRIPT, '--root', self.root, '--base-url', 'http://front/plugin', '--grist-origin', 'http://front', *extra],
                           capture_output=True, text=True, env={'PATH': os.environ.get('PATH', '')})
        return p

    def read(self, rel):
        with open(os.path.join(self.root, 'www', rel), encoding='utf-8') as f:
            return f.read()

    def test_full_sync(self):
        p = self.run_sync()
        self.assertEqual(p.returncode, 0, p.stderr + p.stdout)
        self.assertIn('SYNC: ok', p.stdout)
        self.assertTrue(ProxyHandler.seen, 'les téléchargements doivent passer par le proxy')
        base = 'widget/%s/w/cal/' % self.site_host.replace(':', '_')
        html = self.read(base + 'index.html')
        self.assertIn('http://front/grist-plugin-api.js', html)                       # API des widgets servie par Grist
        self.assertNotIn('docs.getgrist.com', html)
        self.assertIn('src="http://front/plugin/bibjs/lib-1.0/lib.min.js"', html)    # bibliothèque déclarée, même avec ?v=1
        self.assertIn('http://front/plugin/widget/%s/w/common/util.js' % self.site_host.replace(':', '_'), html)  # chemin absolu réécrit
        self.assertIn('src="cal.js"', html)                                            # lien relatif conservé
        self.assertIn('bibjs/ext/%s/css2__' % self.cdn_host.replace(':', '_'), html)  # CSS externe capturé
        self.assertNotIn('integrity=', html)
        self.assertIn('var u="http://front/plugin/bibjs/lib-1.0/lib.min.js"', html)  # URL dans un script en ligne
        self.assertIn('href="http://%s/docs"' % self.cdn_host, html)                  # simple lien : non copié
        for rel in ('cal.js', 'mod.js', 'style.css', 'extra.css', 'bg.png', 'logo.png'):
            self.assertTrue(os.path.isfile(os.path.join(self.root, 'www', base + rel)), rel)
        self.assertTrue(os.path.isfile(os.path.join(self.root, 'www/widget/%s/w/common/util.js' % self.site_host.replace(':', '_'))))
        ext = os.path.join(self.root, 'www/bibjs/ext', self.cdn_host.replace(':', '_'))
        css = [f for f in os.listdir(ext) if f.startswith('css2__')][0]
        self.assertIn('http://front/plugin/bibjs/ext/%s/fonts/f.woff2' % self.cdn_host.replace(':', '_'), open(os.path.join(ext, css)).read())
        self.assertEqual(open(os.path.join(ext, 'fonts/f.woff2'), 'rb').read(), b'FONTDATA')
        # archive : strip + subdir, pas de fuite hors dossier
        self.assertTrue(os.path.isfile(os.path.join(self.root, 'www/widget/arch/wid/app.js')))
        self.assertFalse(os.path.exists(os.path.join(self.root, 'www/widget/arch/skip.txt')))
        self.assertFalse(os.path.exists(os.path.join(self.root, 'evil.txt')))
        self.assertIn('bibjs/lib-1.0/lib.min.js', self.read('widget/arch/wid/index.html'))
        # manifest : manuel + importé (filtre exclude) + archive ; widget d'hôte non autorisé ignoré
        manifest = json.loads(self.read('manifest.json'))
        names = [m['name'] for m in manifest]
        self.assertEqual(names, ['Manuel', 'Calendrier', 'Archive'])
        self.assertTrue(all(m['url'].startswith('http://front/plugin/') for m in manifest))
        cal = manifest[1]
        self.assertEqual((cal['accessLevel'], cal['published']), ('read table', True))
        self.assertIn('Distant', ' '.join(json.load(open(os.path.join(self.sync, 'report.json')))['warnings']))

    def test_idempotent_and_stale_removal(self):
        self.assertEqual(self.run_sync().returncode, 0)
        p = self.run_sync()
        self.assertIn('modifies=0', p.stdout)
        # un fichier déposé à la main n'est jamais touché
        manual = os.path.join(self.root, 'www/widget/manuel/index.html')
        os.makedirs(os.path.dirname(manual))
        with open(manual, 'w', encoding='utf-8') as f:
            f.write('à moi')
        # le widget disparaît de la liste : ses fichiers sont supprimés
        with open(os.path.join(self.sync, 'widgets.json'), encoding='utf-8') as f:
            cfg = json.load(f)
        cfg['manifests'] = []
        self.write('widgets.json', cfg)
        p = self.run_sync()
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertFalse(os.path.exists(os.path.join(self.root, 'www/widget', self.site_host.replace(':', '_'))))
        with open(manual, encoding='utf-8') as f:
            self.assertEqual(f.read(), 'à moi')
        self.assertEqual([m['name'] for m in json.loads(self.read('manifest.json'))], ['Manuel', 'Archive'])

    def test_wrong_proxy_password_changes_nothing(self):
        self.assertEqual(self.run_sync().returncode, 0)
        before = self.read('manifest.json')
        self.write('credentials.json', {'host': '127.0.0.1:%d' % self.proxy.server_port, 'user': USER, 'password': 'mauvais'})
        p = self.run_sync()
        self.assertEqual(p.returncode, 3)
        self.assertIn('407', p.stderr)
        self.assertEqual(self.read('manifest.json'), before)
        self.assertTrue(os.path.isfile(os.path.join(self.root, 'www/bibjs/lib-1.0/lib.min.js')))

    def test_transient_failure_keeps_previous_file(self):
        self.assertEqual(self.run_sync().returncode, 0)
        self.site.RequestHandlerClass = static_handler({k: v for k, v in self.routes.items() if k != '/w/cal/bg.png'})
        try:
            p = self.run_sync()
        finally:
            self.site.RequestHandlerClass = static_handler(self.routes)
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertTrue(os.path.isfile(os.path.join(self.root, 'www/widget/%s/w/cal/bg.png' % self.site_host.replace(':', '_'))))
        self.assertIn('précédente conservée', p.stderr)

    def test_sha256_mismatch_is_rejected(self):
        self.write('bibjs.json', {'libs': [{'name': 'x', 'files': [{'url': 'http://%s/lib/lib.min.js' % self.cdn_host, 'dest': 'x/lib.js', 'sha256': '0' * 64}]}]})
        p = self.run_sync()
        self.assertEqual(p.returncode, 1)
        self.assertIn('sha256', p.stderr)
        self.assertFalse(os.path.exists(os.path.join(self.root, 'www/bibjs/x/lib.js')))

    def test_dry_run_writes_nothing(self):
        p = self.run_sync('--dry-run')
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertFalse(os.path.exists(os.path.join(self.root, 'www/manifest.json')))


if __name__ == '__main__':
    unittest.main(verbosity=2)
