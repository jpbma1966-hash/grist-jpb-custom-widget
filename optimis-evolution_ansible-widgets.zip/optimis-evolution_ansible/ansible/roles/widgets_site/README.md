# Rôle widgets_site

Site statique (conteneur nginx) des widgets Grist et des bibliothèques JavaScript, servi sous
`http://optimis-developpement.minint.fr/plugin/` par le RPX. Son contenu est **téléchargé automatiquement**
par `files/widgets_sync.py` à partir de deux listes JSON, par le proxy authentifiant.

```
files/widgets.json     widgets à télécharger (listes de widgets, archives, widgets isolés)
files/bibjs.json       bibliothèques JavaScript à télécharger (version épinglée, sha256 facultatif)
files/widgets_sync.py  script de synchronisation (Python 3, bibliothèque standard seulement)
files/www/             widgets et bibliothèques déposés à la main (jamais modifiés par la synchronisation)
tests/                 test de bout en bout du script : python3 tests/test_widgets_sync.py
```

Sur le serveur : `/opt/widgets-site/www` (servi), `/opt/widgets-site/sync` (listes, `report.json`, `state.json`).

Déploiement : `ansible-playbook -i inventories/dev/openstack.yml playbooks/widgets.yml`
Synchronisation seule : `systemctl start widgets-sync` ; compte rendu : `cat /opt/widgets-site/sync/report.json`.
Le détail est dans `docs/widgets-site.md`.
