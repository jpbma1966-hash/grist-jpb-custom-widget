# Site des widgets Grist et des bibliothèques JS (chemin `/plugin/`)

Les widgets et les bibliothèques JavaScript sont servis **par votre infrastructure**, en `http://`, sous
`http://optimis-developpement.minint.fr/plugin/`, et **téléchargés automatiquement** depuis des listes JSON, par le
proxy authentifiant. Le manifest que lit Grist est régénéré à chaque synchronisation. Cela supprime les blocages liés à
`github.io` (contenu mixte, CSP, `otherInstance`). Pas de nouveau nom DNS : le RPX ajoute un chemin sur son vhost existant.

```mermaid
flowchart LR
  NET["Internet\n(GitHub, CDN)"] -->|"proxy authentifiant"| SYNC["widgets_sync.py\nopt-flask-python-1"]
  SYNC -->|"widgets.json, bibjs.json"| WWW["/opt/widgets-site/www\nmanifest.json, widget/, bibjs/"]
  WWW --> WS["conteneur nginx :8080"]
  NAV["Navigateur"] -->|"http://optimis-developpement.minint.fr"| RPX["RPX Apache\nvhost grist.conf"]
  RPX -->|"/ (sauf /sso/ et /plugin/)"| GRIST["opt-grist-1 : 8484\nGrist"]
  RPX -->|"/plugin/"| WS
  GRIST -->|"GRIST_WIDGET_LIST_URL\n.../plugin/manifest.json"| RPX
```

```
/plugin/manifest.json                      liste des widgets lue par Grist (générée)
/plugin/widget/<hôte>/<chemin>             widgets téléchargés (arborescence d'origine conservée)
/plugin/widget/<nom>/                      widgets déposés à la main ou extraits d'une archive
/plugin/bibjs/<bibliothèque-version>/      bibliothèques déclarées dans bibjs.json
/plugin/bibjs/ext/<hôte>/<chemin>          dépendances externes capturées automatiquement
```

## 1. Fichiers du dépôt modifiés ou ajoutés

| Fichier | Changement |
|---|---|
| `ansible/roles/widgets_site/` | **nouveau** rôle : conteneur nginx, synchronisation, minuteur systemd |
| `.../files/widgets_sync.py` | script de téléchargement et de génération du manifest |
| `.../files/widgets.json` | **liste des widgets** à télécharger |
| `.../files/bibjs.json` | **liste des bibliothèques JS** à télécharger |
| `.../files/www/` | widgets et bibliothèques déposés à la main (facultatif) |
| `.../tests/test_widgets_sync.py` | test du script avec de faux serveurs et un proxy authentifié |
| `ansible/roles/rpx/templates/app.conf.j2` | règle `ProxyPass /plugin/` **avant** `ProxyPass /` |
| `group_vars/all.yml` | `grist_origin`, `widgets_base_url`, `widgets_port` |
| `group_vars/flask_python.yml` | `widgets_root`, `widgets_image`, `widgets_manifest`, variables de synchronisation et de proxy |
| `group_vars/flask_python/vault.yml.example` | modèle du fichier des identifiants du proxy (à chiffrer) |
| `group_vars/rpx.yml` | `widgets_internal_dns` |
| `group_vars/grist.yml` | `grist_widget_list_url` pointe sur `/plugin/manifest.json` |
| `playbooks/flask.yml`, `deploy_all.yml` | ajout du rôle `widgets_site` sur `flask_python` |
| `playbooks/widgets.yml` | **nouveau** : déploie le site seul |
| `.gitlab-ci.yml` | `widgets.yml` ajouté à la liste des playbooks |
| `terraform/network.tf` | **règle de sécurité** : le RPX peut joindre le port 8080 du serveur Flask |

Le `NO_PROXY` du conteneur Grist n'a pas à changer : il contient déjà `optimis-developpement.minint.fr`.

## 2. Téléchargement automatique

### 2.1 Ce que fait la synchronisation

1. Télécharge les **bibliothèques** de `bibjs.json` (vérifie le `sha256` s'il est renseigné).
2. Télécharge les **widgets** de `widgets.json` : listes de widgets (manifests), archives, widgets isolés.
3. Pour chaque page de widget, télécharge ses **dépendances** (scripts, feuilles de style, images, modules JS,
   polices) et **réécrit les adresses externes** vers le site local. L'API des widgets (`grist-plugin-api.js`) est
   redirigée vers votre Grist.
4. Régénère `manifest.json` : widgets déclarés à la main (`widgets_manifest`), puis widgets téléchargés.
5. Met à jour `www/` fichier par fichier, supprime ce qui n'est plus dans les listes, ne touche jamais aux fichiers
   déposés à la main, et écrit un compte rendu (`sync/report.json`).

Si un téléchargement échoue (réseau, proxy), la **version précédente du fichier est conservée**. Si **aucun** fichier
n'a pu être téléchargé (identifiants refusés par le proxy, par exemple), le site n'est pas modifié.

### 2.2 `widgets.json`

```json
{
  "settings": {
    "widget_hosts": ["*.github.io"],
    "external_hosts": ["cdn.jsdelivr.net", "unpkg.com", "cdnjs.cloudflare.com", "fonts.googleapis.com", "fonts.gstatic.com"],
    "rewrites": { "https://docs.getgrist.com/grist-plugin-api.js": "{GRIST_ORIGIN}/grist-plugin-api.js" }
  },
  "manifests": [
    { "url": "https://github.com/gristlabs/grist-widget/releases/download/latest/manifest.json" },
    { "file": "manifest_fusionne.json", "exclude": ["*test*"] }
  ],
  "archives": [
    { "id": "mes-widgets", "url": "https://github.com/org/depot/archive/refs/heads/main.zip", "strip": 1, "subdir": "public" }
  ],
  "widgets": [
    { "name": "Mon widget", "widgetId": "mon-widget", "archive": "mes-widgets", "entry": "monwidget/index.html", "accessLevel": "full" },
    { "name": "Autre", "widgetId": "autre", "url": "https://org.github.io/depot/autre/index.html", "accessLevel": "read table" }
  ]
}
```

| Clé | Rôle |
|---|---|
| `widget_hosts` | **hôtes autorisés** pour les pages de widgets (jokers acceptés : `*.github.io`). Tout autre hôte est ignoré avec un avertissement |
| `external_hosts` | hôtes autorisés pour les dépendances (CDN). Elles sont copiées dans `bibjs/ext/` |
| `rewrites` | remplacements d'adresses exactes ; `{GRIST_ORIGIN}` et `{BASE_URL}` sont remplacés |
| `manifests` | listes de widgets existantes (`url`, ou `file` placé dans `/opt/widgets-site/sync/`) : tous leurs widgets sont téléchargés et le manifest local reprend leurs descriptions. `include` et `exclude` filtrent par `widgetId` ou nom (jokers) |
| `archives` | archive zip ou tar : `strip` retire des niveaux de dossier, `subdir` ne garde qu'un sous-dossier |
| `widgets` | widgets isolés : par `url` (page à télécharger) ou par `archive` + `entry` |

Pour reprendre votre manifest fusionné, déposez-le dans `roles/widgets_site/files/`, ajoutez-le au `copy` de la tâche
« Listes des widgets » (ou à `files/www/`), puis référencez-le avec `"file"`. Une entrée dont l'hôte n'est pas dans
`widget_hosts` apparaît dans `report.json` : ajoutez l'hôte pour l'inclure.

### 2.3 `bibjs.json`

```json
{
  "libs": [
    { "name": "jszip", "version": "3.10.1",
      "files": [ { "url": "https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js",
                   "dest": "jszip-3.10.1/jszip.min.js",
                   "sha256": "",
                   "aliases": ["https://unpkg.com/jszip@3.10.1/dist/jszip.min.js"] } ] }
  ]
}
```

Chaque fichier va dans `bibjs/<dest>`. Toute référence à son adresse (ou à un `alias`, avec ou sans `?v=`) dans un
widget est réécrite vers la copie locale. Laissez `sha256` vide la première fois : le compte rendu l'affiche, **copiez-le
dans le fichier pour épingler la bibliothèque** (un fichier modifié à la source sera alors refusé).

### 2.4 Proxy authentifiant

Les identifiants ne sont jamais écrits dans le dépôt en clair :

1. Copiez `inventories/dev/group_vars/flask_python/vault.yml.example` en `vault.yml`, renseignez
   `widgets_proxy_user` et `widgets_proxy_password`, puis chiffrez : `ansible-vault encrypt vault.yml`.
2. La CI doit fournir le mot de passe du coffre (`ANSIBLE_VAULT_PASSWORD_FILE` ou `--vault-password-file`).
3. Ansible écrit `/opt/widgets-site/sync/credentials.json` (droits `0600`, lisible par root seulement).
4. Le proxy se règle avec `widgets_proxy_hostport` (par défaut celui de `all.yml`). Les hôtes de `widgets_no_proxy`
   sont joints directement. Si le proxy inspecte le TLS, indiquez `widgets_ca_bundle`.

### 2.5 Mise à jour automatique

Un minuteur systemd lance la synchronisation chaque jour à 3 h 30 (`widgets_sync_calendar`, `widgets_sync_auto`).
Elle se lance aussi à chaque déploiement du rôle.

| Besoin | Commande (sur le serveur Flask) |
|---|---|
| Lancer maintenant | `systemctl start widgets-sync` |
| Voir le résultat | `journalctl -u widgets-sync -n 50` ou `cat /opt/widgets-site/sync/report.json` |
| Essayer sans rien modifier | `python3 /opt/widgets-site/sync/widgets_sync.py --root /opt/widgets-site --base-url <url> --grist-origin <url> --dry-run` |
| Prochain passage | `systemctl list-timers widgets-sync.timer` |

### 2.6 Limites à connaître

- **Adresses construites par le code** (assemblées au moment de l'exécution) : elles ne sont pas détectées. Elles
  apparaissent au mieux dans `external_not_copied` si elles figurent en toutes lettres ; à ajouter alors à `bibjs.json`.
- **Widgets qui nécessitent une compilation** : seul le résultat publié (page déjà construite) est copié.
- **Appels vers des services externes** (API, cartes en ligne, etc.) : non copiés ; ils passent par le navigateur de l'utilisateur.
- Les attributs `integrity` des balises réécrites sont retirés (le contenu a pu changer). Épinglez par `sha256` dans `bibjs.json`.
- **Chaîne d'approvisionnement** : tout widget copié devient du code servi sur votre domaine, avec l'accès demandé dans le
  manifest. Limitez `widget_hosts` et `external_hosts` aux sources que vous acceptez, et relisez les nouveaux widgets
  (compte rendu `widgets` de `report.json`).

## 3. Ce qu'il faut renseigner avant de déployer

1. **Image nginx** : `widgets_image` dans `group_vars/flask_python.yml` (chemin par l'Artifactory, à vérifier).
2. **Identifiants du proxy** : fichier `vault.yml` chiffré (§2.4).
3. **Listes JSON** : adaptez `widgets.json` (listes de widgets, hôtes autorisés) et `bibjs.json`.
4. **Nom du serveur Flask** : `widgets_internal_dns` (`opt-flask-python-1`, le même que `flask_internal_dns` de `arp.yml`).
5. **Widgets à la main** (facultatif) : dans `files/www/widget/<nom>/` ; déclarez-les dans `widgets_manifest`.

Dans les widgets déposés à la main : bibliothèques par chemin relatif (`../../bibjs/jszip-3.10.1/jszip.min.js`) et API des
widgets depuis Grist (`/grist-plugin-api.js`). Pour SyncPlus, `GRIST_ORIGINS` = `http://optimis-developpement.minint.fr`.

## 4. Déploiement, dans cet ordre

| Étape | Action |
|---|---|
| 1 | **Terraform** : appliquer `network.tf` (règle 8080 du RPX vers le serveur Flask). Elle ne recrée aucune machine |
| 2 | Playbook `widgets.yml` (ou `flask.yml`) : conteneur, téléchargement, minuteur |
| 3 | Playbook `rpx.yml` : règle `/plugin/` d'Apache |
| 4 | Playbook `grist.yml` : Grist redémarre et prend la nouvelle liste de widgets |

## 5. Tests

| Test | Commande ou geste | Attendu |
|---|---|---|
| Script | `python3 roles/widgets_site/tests/test_widgets_sync.py` | 6 tests OK |
| Synchronisation | `cat /opt/widgets-site/sync/report.json` | `errors` vide |
| Conteneur | `curl -I http://opt-flask-python-1:8080/manifest.json` (depuis le RPX) | 200 |
| RPX | `curl -I http://optimis-developpement.minint.fr/plugin/manifest.json` | 200, JSON |
| Grist joint le site | `docker exec grist wget -qO- http://optimis-developpement.minint.fr/plugin/manifest.json` | le JSON |
| Liste de widgets | dans un document : Ajouter un widget, Personnalisé | les widgets apparaissent |

| Constat | Cause probable |
|---|---|
| `SYNC: ÉCHEC ... 407` | identifiants du proxy refusés : vérifier le coffre Ansible |
| `SYNC: ÉCHEC ... aucun téléchargement` | proxy ou réseau : tester `curl -x` depuis le serveur ; vérifier `widgets_ca_bundle` |
| Widget absent du manifest | hôte absent de `widget_hosts` (voir les avertissements de `report.json`) |
| Widget affiché mais incomplet | une dépendance vient d'un hôte absent de `external_hosts` (voir `external_not_copied`) |
| `curl` du RPX vers le 8080 bloqué | règle Terraform non appliquée |
| `/plugin/manifest.json` répond par une page de Grist | la règle `/plugin/` est après `ProxyPass /` |
| `otherInstance` dans SyncPlus | `GRIST_ORIGINS` ne contient pas l'adresse exacte de Grist |

## 6. Sécurité et suite

- **Même origine que Grist** : les widgets sont servis sous le même nom d'hôte que l'application, donc avec moins
  d'isolation qu'avec un autre domaine. Un widget à accès complet lit et écrit tout le document : faites valider ce choix
  par votre RSSI. Si un nom DNS devient disponible, un vhost dédié est plus sûr.
- **Fichiers en lecture seule** : le conteneur monte le site en `:ro` et tourne en `read_only`.
- **Pas de secret** dans les widgets, les listes JSON ni le manifest.
- **Passage en https** : changez ensemble le certificat du RPX, `APP_HOME_URL`, `grist_origin` (qui fixe `widgets_base_url`)
  et `GRIST_ORIGINS` de SyncPlus, puis relancez la synchronisation (les adresses réécrites sont recalculées). Un Grist en
  https refuse d'embarquer un widget en http.
- **CSP par en-tête** : `default.conf.j2` contient un exemple commenté pour envoyer la CSP d'un widget par nginx.
- **Secrets du dépôt** : mots de passe et clés en clair (proxy, base de données, stockage objet, secret OIDC, session).
  Passez-les en Ansible Vault et renouvelez ceux qui ont été partagés.
